# VAJRA — Thunderstorm & Lightning Nowcasting System (Prototype)

Redesigned prototype for Smart India Hackathon 2026, Problem Statement 72.
Government-portal visual direction (white/navy, IMD-adjacent conventions) rather
than a dark AI/SaaS dashboard.

## Run it

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build to dist/
```

## Stack

React + TypeScript + Vite + Tailwind CSS v4, Leaflet/react-leaflet for the GIS map,
React Router for navigation. All storm/observation/impact data comes from a single
deterministic simulation engine (`src/simulation/engine.ts`) so every number on
every page stays mathematically consistent — storm position at +30 min really is
where speed x heading says it should be, confidence really does decrease with
horizon, exposed population really is derived from assets actually inside the
projected zone, etc.

## What's fully built

- Government header/nav shell (top strip, ministry identity, VAJRA branding, nav bar)
- **Home** - operational status strip, current-situation summary, no marketing copy
- **Live Map** - real Leaflet map, simplified-but-real Bhopal district geodata
  (boundary, roads, water bodies, settlements, 12 infrastructure assets), storm
  track with a widening uncertainty cone (0/15/30/45/60 min), layer toggle panel,
  legend
- **Nowcast** - full storm-cell data panel + confidence-by-horizon table
- **Impact Assessment** - hazard x exposure x vulnerability formula strip, assets-
  in-zone breakdown, impact-based warning bulletin, role-based recommendations
  (6 roles, each with a distinct action derived from the same hazard state)
- **Alerts** - bulletin-style warning centre with acknowledge/escalate actions
- **Data Sources** - observation fusion table (6 sources), fusion pipeline
  diagram, radar-outage simulation button (dynamically reweights sources live),
  coverage-gap / "virtual radar" panel with a radar-shadow zone on the map
- **Storm Intelligence** - life-cycle stepper, trend indicators, terrain panel
- **Demonstration Mode** - floating control, scripted 10-step sequence
- **Historical Events**, **Analytics** - built with realistic structure and
  labelled prototype metrics, lighter on interactivity than the pages above
- **About** - plain-language scope disclaimer

## Known simplifications (be upfront about these in a demo)

- District boundary / roads / water bodies are simplified illustrative
  coordinates, not survey-accurate shapefiles.
- "Radar" and "Lightning" map layers are represented through the storm-track and
  intensity data already in the simulation, not live tile feeds - the Live Map
  layer panel says this explicitly.
- Scenario Simulator (what-if sliders) and the printable Nowcast Bulletin from
  the original spec are not built yet - Historical Events and Analytics have
  structure and real layout but are the least deep of the pages.
- No backend/API - everything runs from the in-browser simulation engine, by
  design, so it can later be swapped for real IMD/radar feeds via
  `src/services/`.
