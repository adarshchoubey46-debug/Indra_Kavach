import { createContext, useContext, useMemo, useState, useCallback, useRef, type ReactNode } from 'react';
import { buildSimulationState, DEFAULT_PARAMS, type EngineParams } from '../simulation/engine';
import type { Role, SimulationState } from '../types';

interface Ctx {
  state: SimulationState;
  role: Role;
  setRole: (r: Role) => void;
  toggleRadarOutage: () => void;
  demoStep: number; // 0 = inactive
  isDemoRunning: boolean;
  startDemo: () => void;
  stopDemo: () => void;
  acknowledgeAlert: (id: string) => void;
}

const SimulationCtx = createContext<Ctx | null>(null);

const DEMO_STEPS = [
  'Observation data updating',
  'Lightning activity increasing',
  'Convective development on radar/satellite',
  'Storm cell identified',
  'Storm trajectory computed',
  'Confidence and uncertainty updated',
  'Risk zone advancing',
  'Critical infrastructure identified in projected zone',
  'Impact-based warning generated',
  'Role-specific action recommended',
];

export function SimulationProvider({ children }: { children: ReactNode }) {
  const [params] = useState<EngineParams>(DEFAULT_PARAMS);
  const [radarOutage, setRadarOutage] = useState(false);
  const [role, setRole] = useState<Role>('district-administration');
  const [demoStep, setDemoStep] = useState(0);
  const [ackIds, setAckIds] = useState<string[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const rawState = useMemo(() => buildSimulationState(params, radarOutage), [params, radarOutage]);
  const state = useMemo(
    () => ({
      ...rawState,
      alerts: rawState.alerts.map((a) => (ackIds.includes(a.id) ? { ...a, acknowledged: true } : a)),
    }),
    [rawState, ackIds]
  );

  const toggleRadarOutage = useCallback(() => setRadarOutage((v) => !v), []);

  const startDemo = useCallback(() => {
    setDemoStep(1);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setDemoStep((s) => {
        if (s >= DEMO_STEPS.length) {
          if (timerRef.current) clearInterval(timerRef.current);
          return 0;
        }
        return s + 1;
      });
    }, 2200);
  }, []);

  const stopDemo = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    setDemoStep(0);
  }, []);

  const acknowledgeAlert = useCallback((id: string) => {
    setAckIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  }, []);

  const value: Ctx = {
    state,
    role,
    setRole,
    toggleRadarOutage,
    demoStep,
    isDemoRunning: demoStep > 0,
    startDemo,
    stopDemo,
    acknowledgeAlert,
  };

  return <SimulationCtx.Provider value={value}>{children}</SimulationCtx.Provider>;
}

export function useSimulation() {
  const ctx = useContext(SimulationCtx);
  if (!ctx) throw new Error('useSimulation must be used within SimulationProvider');
  return ctx;
}

export const DEMO_STEP_LABELS = DEMO_STEPS;
