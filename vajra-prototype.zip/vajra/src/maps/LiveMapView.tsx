import { useMemo, useState } from 'react';
import { MapContainer, TileLayer, Polygon, Polyline, Circle, CircleMarker, Tooltip, LayersControl, Pane } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import {
  BHOPAL_DISTRICT_BOUNDARY,
  MAJOR_ROADS,
  WATER_BODIES,
  SETTLEMENTS,
  INFRASTRUCTURE_ASSETS,
  RADAR_SHADOW_ZONE,
  BHOPAL_CENTER,
} from '../data/geo';
import { useSimulation } from '../services/SimulationContext';
import type { InfrastructureAsset } from '../types';

const ASSET_COLORS: Record<InfrastructureAsset['type'], string> = {
  school: '#0d5aa7',
  hospital: '#b3231c',
  highway: '#55606a',
  railway: '#4b3b14',
  construction: '#c15a08',
  village: '#1c7d3f',
  substation: '#7a1fa2',
  city: '#0b2545',
};

const CONE_COLOR = '#c15a08';

export function LiveMapView({ showInfrastructure = true, showRadarShadow = false, height = '560px' }: { showInfrastructure?: boolean; showRadarShadow?: boolean; height?: string }) {
  const { state } = useSimulation();
  const storm = state.storm;
  const [showLayer] = useState({
    boundary: true,
    roads: true,
    water: true,
    settlements: true,
    track: true,
    infra: showInfrastructure,
    radarShadow: showRadarShadow,
  });

  const trackLatLngs = useMemo(() => storm.track.map((p) => [p.lat, p.lng] as [number, number]), [storm.track]);

  return (
    <div className="relative border" style={{ borderColor: 'var(--gov-border)' }}>
      <MapContainer
        center={[BHOPAL_CENTER.lat, BHOPAL_CENTER.lng]}
        zoom={10}
        style={{ height, width: '100%', background: '#eef2f5' }}
        scrollWheelZoom
      >
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="Base Map (OSM)">
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Satellite (Esri)">
            <TileLayer
              attribution="Tiles &copy; Esri"
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Terrain (OpenTopoMap)">
            <TileLayer
              attribution='Map data: &copy; OpenStreetMap contributors, SRTM | Map style: &copy; OpenTopoMap'
              url="https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
        </LayersControl>

        <Pane name="district" style={{ zIndex: 350 }}>
          {showLayer.boundary && (
            <Polygon
              positions={BHOPAL_DISTRICT_BOUNDARY.map((p) => [p.lat, p.lng])}
              pathOptions={{ color: '#0b2545', weight: 2, fillOpacity: 0.02, dashArray: '4 3' }}
            >
              <Tooltip sticky>Bhopal District Boundary</Tooltip>
            </Polygon>
          )}
        </Pane>

        {showLayer.water &&
          WATER_BODIES.map((w) => (
            <Polygon key={w.name} positions={w.path.map((p) => [p.lat, p.lng])} pathOptions={{ color: '#2b6ea8', weight: 1, fillColor: '#a9cdea', fillOpacity: 0.55 }}>
              <Tooltip sticky>{w.name}</Tooltip>
            </Polygon>
          ))}

        {showLayer.roads &&
          MAJOR_ROADS.map((r) => (
            <Polyline key={r.name} positions={r.path.map((p) => [p.lat, p.lng])} pathOptions={{ color: '#8a6d3b', weight: 2, opacity: 0.8 }}>
              <Tooltip sticky>{r.name}</Tooltip>
            </Polyline>
          ))}

        {showLayer.settlements &&
          SETTLEMENTS.map((s) => (
            <CircleMarker
              key={s.name}
              center={[s.position.lat, s.position.lng]}
              radius={s.kind === 'city' ? 6 : s.kind === 'town' ? 4 : 3}
              pathOptions={{ color: '#0b2545', weight: 1, fillColor: '#0b2545', fillOpacity: 0.8 }}
            >
              <Tooltip>{s.name}</Tooltip>
            </CircleMarker>
          ))}

        {showLayer.radarShadow && (
          <Polygon
            positions={RADAR_SHADOW_ZONE.map((p) => [p.lat, p.lng])}
            pathOptions={{ color: '#7c8b98', weight: 1, fillColor: '#7c8b98', fillOpacity: 0.25, dashArray: '3 3' }}
          >
            <Tooltip sticky>Radar coverage gap (simulated)</Tooltip>
          </Polygon>
        )}

        {showLayer.infra &&
          INFRASTRUCTURE_ASSETS.map((a) => (
            <CircleMarker
              key={a.id}
              center={[a.position.lat, a.position.lng]}
              radius={5}
              pathOptions={{ color: ASSET_COLORS[a.type], weight: 1.5, fillColor: ASSET_COLORS[a.type], fillOpacity: 0.9 }}
            >
              <Tooltip>
                {a.name} ({a.type})
              </Tooltip>
            </CircleMarker>
          ))}

        {/* Storm trajectory + widening uncertainty cone */}
        {showLayer.track && (
          <>
            <Polyline positions={trackLatLngs} pathOptions={{ color: CONE_COLOR, weight: 2.5, dashArray: '6 4' }} />
            {storm.track.map((p) => (
              <Circle
                key={p.tMinutes}
                center={[p.lat, p.lng]}
                radius={p.radiusKm * 1000}
                pathOptions={{
                  color: CONE_COLOR,
                  weight: 1,
                  fillColor: CONE_COLOR,
                  fillOpacity: p.tMinutes === 0 ? 0.28 : 0.08 + (60 - p.tMinutes) / 600,
                }}
              >
                <Tooltip sticky>
                  {p.tMinutes === 0 ? 'Current Cell' : `+${p.tMinutes} min`} — confidence {p.confidencePct}%
                </Tooltip>
              </Circle>
            ))}
            {storm.track.map((p) => (
              <CircleMarker key={`pt-${p.tMinutes}`} center={[p.lat, p.lng]} radius={3} pathOptions={{ color: '#7a1706', fillColor: '#7a1706', fillOpacity: 1, weight: 1 }} />
            ))}
          </>
        )}
      </MapContainer>

      <MapLegend />
    </div>
  );
}

function MapLegend() {
  return (
    <div
      className="absolute bottom-3 left-3 z-[1000] rounded-sm border bg-white/95 px-3 py-2 text-[11.5px] shadow-sm backdrop-blur-sm"
      style={{ borderColor: 'var(--gov-border)' }}
    >
      <div className="mb-1 font-semibold" style={{ color: 'var(--gov-navy)' }}>
        Risk Legend
      </div>
      <div className="flex flex-col gap-1">
        {[
          { c: 'var(--status-safe)', l: 'LOW' },
          { c: 'var(--status-watch)', l: 'MODERATE' },
          { c: 'var(--status-warn)', l: 'HIGH' },
          { c: 'var(--status-severe)', l: 'SEVERE' },
        ].map((r) => (
          <div key={r.l} className="flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: r.c }} />
            <span style={{ color: 'var(--gov-text-muted)' }}>{r.l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
