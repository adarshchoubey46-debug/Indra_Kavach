export type RiskLevel = 'low' | 'moderate' | 'high' | 'severe';
export type SourceStatus = 'operational' | 'degraded' | 'unavailable';
export type StormStage = 'initiating' | 'developing' | 'mature' | 'decaying';
export type Role =
  | 'meteorological-officer'
  | 'district-administration'
  | 'disaster-management'
  | 'school-administration'
  | 'utility-operator'
  | 'public';

export interface LatLng {
  lat: number;
  lng: number;
}

export interface StormPosition extends LatLng {
  tMinutes: number; // offset from now, e.g. 0, 15, 30, 45, 60
  confidencePct: number;
  radiusKm: number; // uncertainty cone radius at this horizon
}

export interface StormCell {
  id: string; // e.g. MP-TH-042
  stage: StormStage;
  headingDeg: number; // compass bearing
  speedKmh: number;
  thunderstormProbabilityPct: number;
  lightningProbabilityPct: number;
  intensity: 'weak' | 'moderate' | 'strong' | 'severe';
  lightningRatePerMin: number;
  reflectivityDbz: number;
  track: StormPosition[]; // includes t=0 current position
  predictionConfidencePct: number;
}

export interface ObservationSource {
  id: string;
  name: string;
  status: SourceStatus;
  lastUpdateIso: string;
  resolution: string;
  coveragePct: number;
  qualityPct: number;
  modelWeightPct: number;
}

export interface InfrastructureAsset {
  id: string;
  type: 'school' | 'hospital' | 'highway' | 'railway' | 'construction' | 'village' | 'substation' | 'city';
  name: string;
  position: LatLng;
}

export interface ImpactAssessment {
  exposedPopulation: number;
  criticalFacilities: number;
  outdoorExposure: 'low' | 'moderate' | 'high';
  assetsInZone: InfrastructureAsset[];
  riskLevel: RiskLevel;
}

export interface AlertBulletin {
  id: string;
  severity: RiskLevel;
  hazard: string;
  area: string;
  issuedIso: string;
  validUntilIso: string;
  confidencePct: number;
  action: string;
  acknowledged: boolean;
}

export interface VerificationRecord {
  eventId: string;
  locationErrorKm: number;
  arrivalTimeErrorMin: number;
  pod: number; // probability of detection
  far: number; // false alarm ratio
  csi: number; // critical success index
  avgLeadTimeMin: number;
}

export interface SimulationState {
  nowIso: string;
  systemStatus: 'operational' | 'degraded' | 'maintenance';
  activeCells: number;
  highRiskZones: number;
  storm: StormCell;
  sources: ObservationSource[];
  impact: ImpactAssessment;
  alerts: AlertBulletin[];
  radarOutage: boolean;
}
