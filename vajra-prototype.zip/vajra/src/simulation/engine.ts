import type {
  AlertBulletin,
  ImpactAssessment,
  ObservationSource,
  SimulationState,
  StormCell,
  StormPosition,
} from '../types';
import { BHOPAL_CENTER, INFRASTRUCTURE_ASSETS } from '../data/geo';

// Earth-radius based destination point given bearing (deg) and distance (km)
function destinationPoint(lat: number, lng: number, bearingDeg: number, distanceKm: number) {
  const R = 6371;
  const bearing = (bearingDeg * Math.PI) / 180;
  const lat1 = (lat * Math.PI) / 180;
  const lng1 = (lng * Math.PI) / 180;
  const angDist = distanceKm / R;

  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angDist) + Math.cos(lat1) * Math.sin(angDist) * Math.cos(bearing)
  );
  const lng2 =
    lng1 +
    Math.atan2(
      Math.sin(bearing) * Math.sin(angDist) * Math.cos(lat1),
      Math.cos(angDist) - Math.sin(lat1) * Math.sin(lat2)
    );

  return { lat: (lat2 * 180) / Math.PI, lng: (lng2 * 180) / Math.PI };
}

function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export interface EngineParams {
  headingDeg: number;
  speedKmh: number;
  intensity: StormCell['intensity'];
  lightningRatePerMin: number;
  originOffsetKm: { south: number; west: number }; // where current cell sits relative to Bhopal centre
}

export const DEFAULT_PARAMS: EngineParams = {
  headingDeg: 32, // NNE-ish, matches "NE" label
  speedKmh: 24,
  intensity: 'strong',
  lightningRatePerMin: 18,
  originOffsetKm: { south: 22, west: 18 }, // storm currently SW of Bhopal, tracking toward it
};

const CONFIDENCE_BY_HORIZON: Record<number, number> = {
  0: 97,
  15: 93,
  30: 87,
  45: 73,
  60: 59,
};

const CONE_RADIUS_KM_BY_HORIZON: Record<number, number> = {
  0: 2,
  15: 4,
  30: 8,
  45: 13,
  60: 19,
};

function buildTrack(params: EngineParams): StormPosition[] {
  const origin = destinationPoint(BHOPAL_CENTER.lat, BHOPAL_CENTER.lng, 180, params.originOffsetKm.south);
  const origin2 = destinationPoint(origin.lat, origin.lng, 270, params.originOffsetKm.west);

  const horizons = [0, 15, 30, 45, 60];
  return horizons.map((t) => {
    const distanceKm = (params.speedKmh * t) / 60;
    const pos = destinationPoint(origin2.lat, origin2.lng, params.headingDeg, distanceKm);
    return {
      ...pos,
      tMinutes: t,
      confidencePct: CONFIDENCE_BY_HORIZON[t],
      radiusKm: CONE_RADIUS_KM_BY_HORIZON[t],
    };
  });
}

function estimateArrivalWindow(track: StormPosition[]): { minMin: number; maxMin: number } {
  // Distance from t=0 cell to Bhopal centre, interpolated across track / speed
  const current = track[0];
  const distKm = haversineKm(current, BHOPAL_CENTER);
  const speedProxy = haversineKm(track[0], track[1]) / (track[1].tMinutes - track[0].tMinutes || 1); // km/min
  const centerMin = speedProxy > 0 ? distKm / speedProxy : 30;
  return { minMin: Math.max(1, Math.round(centerMin - 6)), maxMin: Math.round(centerMin + 6) };
}

export function buildStormCell(params: EngineParams = DEFAULT_PARAMS): StormCell {
  const track = buildTrack(params);
  const probByIntensity: Record<StormCell['intensity'], number> = {
    weak: 42,
    moderate: 64,
    strong: 86,
    severe: 95,
  };
  const lightningProbByRate = Math.min(97, 55 + params.lightningRatePerMin * 2);

  return {
    id: 'MP-TH-042',
    stage: 'developing',
    headingDeg: params.headingDeg,
    speedKmh: params.speedKmh,
    thunderstormProbabilityPct: probByIntensity[params.intensity],
    lightningProbabilityPct: Math.round(lightningProbByRate),
    intensity: params.intensity,
    lightningRatePerMin: params.lightningRatePerMin,
    reflectivityDbz: params.intensity === 'severe' ? 58 : params.intensity === 'strong' ? 51 : 42,
    track,
    predictionConfidencePct: 87,
  };
}

export function arrivalWindowLabel(storm: StormCell): string {
  const w = estimateArrivalWindow(storm.track);
  return `${w.minMin}\u2013${w.maxMin} min`;
}

export function headingToCompass(deg: number): string {
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}

export function buildSources(radarOutage = false): ObservationSource[] {
  return [
    {
      id: 'radar',
      name: 'Radar',
      status: radarOutage ? 'unavailable' : 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: '1 km',
      coveragePct: radarOutage ? 0 : 84,
      qualityPct: radarOutage ? 0 : 94,
      modelWeightPct: radarOutage ? 0 : 34,
    },
    {
      id: 'satellite',
      name: 'Satellite',
      status: 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: '1 km',
      coveragePct: 100,
      qualityPct: 91,
      modelWeightPct: radarOutage ? 30 : 22,
    },
    {
      id: 'lightning',
      name: 'Lightning Network',
      status: 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: 'Near real-time',
      coveragePct: 96,
      qualityPct: 97,
      modelWeightPct: radarOutage ? 28 : 20,
    },
    {
      id: 'aws',
      name: 'Automatic Weather Stations',
      status: 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: 'Station',
      coveragePct: 82,
      qualityPct: 83,
      modelWeightPct: radarOutage ? 14 : 10,
    },
    {
      id: 'nwp',
      name: 'NWP / Model Guidance',
      status: 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: '3 km',
      coveragePct: 100,
      qualityPct: 89,
      modelWeightPct: radarOutage ? 8 : 8,
    },
    {
      id: 'dem',
      name: 'DEM / Terrain',
      status: 'operational',
      lastUpdateIso: new Date().toISOString(),
      resolution: '30 m',
      coveragePct: 100,
      qualityPct: 99,
      modelWeightPct: 6,
    },
  ];
}

export function buildImpact(storm: StormCell): ImpactAssessment {
  const zoneCenter = storm.track[1]; // +15 min position as the near-term projected zone
  const zoneRadiusKm = storm.track[1].radiusKm + 6;
  const assetsInZone = INFRASTRUCTURE_ASSETS.filter(
    (a) => haversineKm(a.position, zoneCenter) <= zoneRadiusKm
  );
  const exposedPopulation = 6200 + assetsInZone.length * 1350; // deterministic prototype formula
  return {
    exposedPopulation,
    criticalFacilities: assetsInZone.filter((a) => ['school', 'hospital', 'substation'].includes(a.type)).length,
    outdoorExposure: storm.intensity === 'severe' ? 'high' : storm.intensity === 'strong' ? 'high' : 'moderate',
    assetsInZone,
    riskLevel: storm.thunderstormProbabilityPct > 90 ? 'severe' : storm.thunderstormProbabilityPct > 75 ? 'high' : storm.thunderstormProbabilityPct > 50 ? 'moderate' : 'low',
  };
}

export function buildAlerts(storm: StormCell, impact: ImpactAssessment): AlertBulletin[] {
  const now = new Date();
  const valid = new Date(now.getTime() + 33 * 60000);
  const severityMap: Record<typeof impact.riskLevel, AlertBulletin['severity']> = {
    low: 'low',
    moderate: 'moderate',
    high: 'high',
    severe: 'severe',
  };
  return [
    {
      id: 'ALT-2026-0914',
      severity: severityMap[impact.riskLevel],
      hazard: 'Thunderstorm with lightning',
      area: 'Bhopal East (Huzur, Kolar Road belt)',
      issuedIso: now.toISOString(),
      validUntilIso: valid.toISOString(),
      confidencePct: storm.predictionConfidencePct,
      action: 'Restrict outdoor activity in exposed locations; suspend outdoor work at construction sites in the projected path.',
      acknowledged: false,
    },
  ];
}

export function buildSimulationState(params: EngineParams = DEFAULT_PARAMS, radarOutage = false): SimulationState {
  const storm = buildStormCell(params);
  const sources = buildSources(radarOutage);
  const impact = buildImpact(storm);
  const alerts = buildAlerts(storm, impact);
  return {
    nowIso: new Date().toISOString(),
    systemStatus: 'operational',
    activeCells: 3,
    highRiskZones: 7,
    storm,
    sources,
    impact,
    alerts,
    radarOutage,
  };
}

export { haversineKm, destinationPoint };
