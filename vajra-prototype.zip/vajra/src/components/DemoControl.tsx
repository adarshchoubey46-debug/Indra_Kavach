import { useSimulation, DEMO_STEP_LABELS } from '../services/SimulationContext';

export function DemoControl() {
  const { demoStep, isDemoRunning, startDemo, stopDemo } = useSimulation();

  return (
    <div className="fixed bottom-4 right-4 z-[1200] w-[300px] border shadow-md" style={{ borderColor: 'var(--gov-border-strong)', background: '#fff' }}>
      <div className="flex items-center justify-between border-b px-3 py-2" style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-navy)' }}>
        <span className="text-[12px] font-semibold text-white">Demonstration Mode</span>
        {!isDemoRunning ? (
          <button onClick={startDemo} className="rounded-sm px-2 py-1 text-[11px] font-semibold" style={{ background: '#fff', color: 'var(--gov-navy)' }}>
            START DEMONSTRATION
          </button>
        ) : (
          <button onClick={stopDemo} className="rounded-sm border border-white/50 px-2 py-1 text-[11px] font-semibold text-white">
            Stop
          </button>
        )}
      </div>
      {isDemoRunning && (
        <div className="max-h-[220px] overflow-y-auto px-3 py-2">
          {DEMO_STEP_LABELS.map((label, i) => {
            const stepNum = i + 1;
            const done = stepNum < demoStep;
            const active = stepNum === demoStep;
            return (
              <div key={label} className="flex items-center gap-2 py-1 text-[12px]">
                <span
                  className="flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-[9px] font-bold"
                  style={{
                    background: done ? 'var(--status-safe)' : active ? 'var(--gov-blue)' : 'var(--gov-bg-alt)',
                    color: done || active ? '#fff' : 'var(--gov-text-faint)',
                  }}
                >
                  {done ? '✓' : stepNum}
                </span>
                <span style={{ color: active ? 'var(--gov-navy)' : done ? 'var(--gov-text-muted)' : 'var(--gov-text-faint)', fontWeight: active ? 600 : 400 }}>
                  {label}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
