import type { ReactNode } from 'react';
import { TopStrip } from './TopStrip';
import { Header } from './Header';
import { NavBar } from './NavBar';

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col" style={{ background: 'var(--gov-bg-alt)' }}>
      <TopStrip />
      <Header />
      <NavBar />
      <main id="main-content" className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-4">
        {children}
      </main>
      <footer className="border-t py-4 text-center text-[11.5px]" style={{ borderColor: 'var(--gov-border)', color: 'var(--gov-text-faint)', background: '#ffffff' }}>
        <p>VAJRA — Thunderstorm &amp; Lightning Nowcasting System — Prototype developed for Smart India Hackathon 2026 (Problem Statement 72)</p>
        <p className="mt-0.5">All observation values, storm positions and impact figures on this prototype are simulated for demonstration purposes.</p>
      </footer>
    </div>
  );
}
