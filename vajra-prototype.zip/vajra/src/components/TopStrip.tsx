export function TopStrip() {
  return (
    <div className="w-full text-[12px]" style={{ background: 'var(--topstrip-bg)', color: '#e7edf5' }}>
      <div className="mx-auto flex max-w-[1440px] items-center justify-between px-4 py-1.5">
        <span className="font-medium">भारत सरकार | Government of India</span>
        <nav className="flex items-center gap-4">
          <a href="#main-content" className="underline decoration-dotted underline-offset-2 hover:text-white">
            Skip to Main Content
          </a>
          <button className="hover:text-white">Accessibility</button>
          <button className="hover:text-white">हिन्दी | English</button>
          <div className="flex items-center gap-1 border-l border-white/20 pl-3">
            <span className="text-white/70">A</span>
            <button className="rounded-sm border border-white/30 px-1 hover:bg-white/10" aria-label="Decrease font size">A-</button>
            <button className="rounded-sm border border-white/30 px-1 hover:bg-white/10" aria-label="Increase font size">A+</button>
          </div>
          <button className="hover:text-white">Contact</button>
        </nav>
      </div>
    </div>
  );
}
