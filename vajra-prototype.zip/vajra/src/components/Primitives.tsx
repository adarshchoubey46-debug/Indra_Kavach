import type { ReactNode } from 'react';
import type { RiskLevel, SourceStatus } from '../types';

const RISK_STYLES: Record<RiskLevel, { bg: string; fg: string; label: string }> = {
  low: { bg: 'var(--status-safe-bg)', fg: 'var(--status-safe)', label: 'LOW' },
  moderate: { bg: 'var(--status-watch-bg)', fg: 'var(--status-watch)', label: 'MODERATE' },
  high: { bg: 'var(--status-warn-bg)', fg: 'var(--status-warn)', label: 'HIGH' },
  severe: { bg: 'var(--status-severe-bg)', fg: 'var(--status-severe)', label: 'SEVERE' },
};

export function RiskBadge({ level, small }: { level: RiskLevel; small?: boolean }) {
  const s = RISK_STYLES[level];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-sm border font-semibold ${small ? 'px-1.5 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'}`}
      style={{ background: s.bg, color: s.fg, borderColor: s.fg + '33' }}
    >
      <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: s.fg }} />
      {s.label}
    </span>
  );
}

const STATUS_STYLES: Record<SourceStatus, { bg: string; fg: string; label: string }> = {
  operational: { bg: 'var(--status-safe-bg)', fg: 'var(--status-safe)', label: 'Operational' },
  degraded: { bg: 'var(--status-watch-bg)', fg: 'var(--status-watch)', label: 'Degraded' },
  unavailable: { bg: 'var(--status-severe-bg)', fg: 'var(--status-severe)', label: 'Unavailable' },
};

export function StatusPill({ status }: { status: SourceStatus }) {
  const s = STATUS_STYLES[status];
  return (
    <span className="inline-flex items-center gap-1.5 rounded-sm px-2 py-0.5 text-xs font-medium" style={{ background: s.bg, color: s.fg }}>
      <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: s.fg }} />
      {s.label}
    </span>
  );
}

export function Panel({ title, action, children, className = '' }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`border bg-white ${className}`} style={{ borderColor: 'var(--gov-border)' }}>
      {title && (
        <header
          className="flex items-center justify-between border-b px-3.5 py-2"
          style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-bg-panel)' }}
        >
          <h3 className="text-[13px] font-semibold tracking-wide" style={{ color: 'var(--gov-navy)' }}>
            {title}
          </h3>
          {action}
        </header>
      )}
      <div className="p-3.5">{children}</div>
    </section>
  );
}

export function DataRow({ label, value, mono = true }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between border-b py-1.5 last:border-b-0" style={{ borderColor: 'var(--gov-border)' }}>
      <span className="text-[12.5px]" style={{ color: 'var(--gov-text-muted)' }}>
        {label}
      </span>
      <span className={`text-[13.5px] font-semibold ${mono ? 'font-mono-data' : ''}`} style={{ color: 'var(--gov-text)' }}>
        {value}
      </span>
    </div>
  );
}

export function PageHeading({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-4 flex items-start justify-between gap-4 border-b pb-3" style={{ borderColor: 'var(--gov-border)' }}>
      <div>
        <h1 className="text-[19px] font-bold" style={{ color: 'var(--gov-navy)' }}>
          {title}
        </h1>
        {subtitle && (
          <p className="mt-0.5 text-[13px]" style={{ color: 'var(--gov-text-muted)' }}>
            {subtitle}
          </p>
        )}
      </div>
      {actions}
    </div>
  );
}

export function SimulatedTag() {
  return (
    <span
      className="inline-block rounded-sm border px-1.5 py-0.5 text-[10.5px] font-medium tracking-wide"
      style={{ borderColor: 'var(--gov-border-strong)', color: 'var(--gov-text-faint)', background: 'var(--gov-bg-alt)' }}
    >
      PROTOTYPE — SIMULATED DATA
    </span>
  );
}
