import { useClock, formatIst, formatIstDate } from '../utils/useClock';
import { useSimulation } from '../services/SimulationContext';

function EmblemPlaceholder() {
  return (
    <div
      aria-hidden
      className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full border-2 text-[9px] font-bold leading-tight"
      style={{ borderColor: 'var(--gov-navy)', color: 'var(--gov-navy)' }}
    >
      GOI
    </div>
  );
}

export function Header() {
  const now = useClock(30000);
  const { state } = useSimulation();

  return (
    <header className="w-full border-b" style={{ background: 'var(--header-bg)', borderColor: 'var(--gov-border)' }}>
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-6 px-4 py-3">
        <div className="flex items-center gap-3">
          <EmblemPlaceholder />
          <div className="leading-tight">
            <div className="text-[13.5px] font-semibold" style={{ color: 'var(--gov-navy)' }}>
              Ministry of Earth Sciences
            </div>
            <div className="text-[11.5px]" style={{ color: 'var(--gov-text-muted)' }}>
              Government of India
            </div>
          </div>
        </div>

        <div className="hidden flex-col items-center md:flex">
          <div className="flex items-baseline gap-2">
            <span className="text-[22px] font-extrabold tracking-tight" style={{ color: 'var(--gov-navy)' }}>
              VAJRA
            </span>
            <span className="text-[12.5px] font-medium" style={{ color: 'var(--gov-text-muted)' }}>
              Thunderstorm &amp; Lightning Nowcasting System
            </span>
          </div>
          <span className="text-[10.5px] italic" style={{ color: 'var(--gov-text-faint)' }}>
            From Atmospheric Observations to Actionable Decisions
          </span>
        </div>

        <div className="flex items-center gap-4 text-right">
          <div className="hidden sm:block">
            <div className="text-[11px]" style={{ color: 'var(--gov-text-faint)' }}>
              {formatIstDate(now)}
            </div>
            <div className="text-[13px] font-semibold font-mono-data" style={{ color: 'var(--gov-text)' }}>
              {formatIst(now)}
            </div>
          </div>
          <div className="flex items-center gap-1.5 rounded-sm border px-2.5 py-1.5" style={{ borderColor: 'var(--status-safe)', background: 'var(--status-safe-bg)' }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: 'var(--status-safe)' }} />
            <span className="text-[11.5px] font-semibold" style={{ color: 'var(--status-safe)' }}>
              System {state.systemStatus === 'operational' ? 'Operational' : state.systemStatus}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
