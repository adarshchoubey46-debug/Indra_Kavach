import { NavLink } from 'react-router-dom';

const ITEMS: { to: string; label: string }[] = [
  { to: '/', label: 'Home' },
  { to: '/nowcast', label: 'Nowcast' },
  { to: '/live-map', label: 'Live Map' },
  { to: '/storm-intelligence', label: 'Storm Intelligence' },
  { to: '/impact-assessment', label: 'Impact Assessment' },
  { to: '/alerts', label: 'Alerts' },
  { to: '/historical-events', label: 'Historical Events' },
  { to: '/analytics', label: 'Analytics' },
  { to: '/data-sources', label: 'Data Sources' },
  { to: '/about', label: 'About' },
];

export function NavBar() {
  return (
    <nav style={{ background: 'var(--nav-bg)' }} aria-label="Primary">
      <div className="mx-auto flex max-w-[1440px] items-stretch overflow-x-auto px-2">
        {ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `whitespace-nowrap px-3.5 py-2.5 text-[13px] font-medium transition-colors ${
                isActive ? 'text-white' : 'text-[#cdddf0] hover:text-white'
              }`
            }
            style={({ isActive }) => ({
              background: isActive ? 'var(--nav-bg-hover)' : 'transparent',
              borderBottom: isActive ? '2px solid #ffffff' : '2px solid transparent',
            })}
          >
            {item.label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
