import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { SimulationProvider } from './services/SimulationContext';
import { Layout } from './components/Layout';
import { DemoControl } from './components/DemoControl';
import { Home } from './pages/Home';
import { Nowcast } from './pages/Nowcast';
import { LiveMap } from './pages/LiveMap';
import { StormIntelligence } from './pages/StormIntelligence';
import { ImpactAssessment } from './pages/ImpactAssessment';
import { Alerts } from './pages/Alerts';
import { HistoricalEvents } from './pages/HistoricalEvents';
import { Analytics } from './pages/Analytics';
import { DataSources } from './pages/DataSources';
import { About } from './pages/About';

function App() {
  return (
    <SimulationProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/nowcast" element={<Nowcast />} />
            <Route path="/live-map" element={<LiveMap />} />
            <Route path="/storm-intelligence" element={<StormIntelligence />} />
            <Route path="/impact-assessment" element={<ImpactAssessment />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/historical-events" element={<HistoricalEvents />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/data-sources" element={<DataSources />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </Layout>
        <DemoControl />
      </BrowserRouter>
    </SimulationProvider>
  );
}

export default App;
