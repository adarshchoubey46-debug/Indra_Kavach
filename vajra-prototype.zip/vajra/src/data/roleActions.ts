import type { Role } from '../types';

export const ROLE_LABELS: Record<Role, string> = {
  'meteorological-officer': 'Meteorological Officer',
  'district-administration': 'District Administration',
  'disaster-management': 'Disaster Management',
  'school-administration': 'School Administration',
  'utility-operator': 'Utility Operator',
  public: 'Public',
};

export function recommendedAction(role: Role): string {
  switch (role) {
    case 'meteorological-officer':
      return 'Verify convective signature against satellite and lightning trend; confirm nowcast before bulletin issuance.';
    case 'district-administration':
      return 'Prepare emergency response resources in the projected impact zone and alert local field offices.';
    case 'disaster-management':
      return 'Place quick-response teams on standby for the Bhopal East sector; pre-position resources near exposed settlements.';
    case 'school-administration':
      return 'Move students indoors and suspend outdoor activity until the warning is withdrawn.';
    case 'utility-operator':
      return 'Monitor exposed electrical infrastructure, in particular the 132kV substation in the projected path.';
    case 'public':
      return 'Avoid open areas and isolated trees; move indoors if lightning is audible or visible nearby.';
    default:
      return '';
  }
}
