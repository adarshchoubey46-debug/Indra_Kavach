import type { InfrastructureAsset, LatLng } from '../types';

// Bhopal district — approximate simplified boundary (not survey-accurate; for prototype visualization only)
export const BHOPAL_DISTRICT_BOUNDARY: LatLng[] = [
  { lat: 23.4200, lng: 77.2200 },
  { lat: 23.4600, lng: 77.3400 },
  { lat: 23.4500, lng: 77.4800 },
  { lat: 23.3900, lng: 77.5800 },
  { lat: 23.3100, lng: 77.6100 },
  { lat: 23.2100, lng: 77.5600 },
  { lat: 23.1400, lng: 77.4800 },
  { lat: 23.1200, lng: 77.3600 },
  { lat: 23.1700, lng: 77.2600 },
  { lat: 23.2700, lng: 77.2000 },
  { lat: 23.4200, lng: 77.2200 },
];

export const BHOPAL_CENTER: LatLng = { lat: 23.2599, lng: 77.4126 };

export const MAJOR_ROADS: { name: string; path: LatLng[] }[] = [
  {
    name: 'NH-46 (Bhopal–Indore corridor)',
    path: [
      { lat: 23.44, lng: 77.20 },
      { lat: 23.34, lng: 77.30 },
      { lat: 23.26, lng: 77.41 },
      { lat: 23.16, lng: 77.50 },
    ],
  },
  {
    name: 'NH-12 (Bhopal–Jabalpur corridor)',
    path: [
      { lat: 23.26, lng: 77.41 },
      { lat: 23.34, lng: 77.52 },
      { lat: 23.40, lng: 77.60 },
    ],
  },
  {
    name: 'SH-18',
    path: [
      { lat: 23.26, lng: 77.41 },
      { lat: 23.18, lng: 77.34 },
      { lat: 23.13, lng: 77.28 },
    ],
  },
];

export const WATER_BODIES: { name: string; path: LatLng[] }[] = [
  {
    name: 'Upper Lake (Bhoj Wetland)',
    path: [
      { lat: 23.245, lng: 77.335 },
      { lat: 23.262, lng: 77.345 },
      { lat: 23.258, lng: 77.368 },
      { lat: 23.238, lng: 77.360 },
      { lat: 23.232, lng: 77.340 },
      { lat: 23.245, lng: 77.335 },
    ],
  },
  {
    name: 'Kolar River (segment)',
    path: [
      { lat: 23.10, lng: 77.36 },
      { lat: 23.18, lng: 77.38 },
      { lat: 23.24, lng: 77.39 },
    ],
  },
];

export const SETTLEMENTS: { name: string; position: LatLng; kind: 'city' | 'town' | 'village' }[] = [
  { name: 'Bhopal (city centre)', position: { lat: 23.2599, lng: 77.4126 }, kind: 'city' },
  { name: 'Berasia', position: { lat: 23.6390, lng: 77.4310 }, kind: 'town' },
  { name: 'Phanda', position: { lat: 23.2760, lng: 77.2890 }, kind: 'town' },
  { name: 'Huzur', position: { lat: 23.1850, lng: 77.4610 }, kind: 'village' },
  { name: 'Kolar', position: { lat: 23.1600, lng: 77.3700 }, kind: 'village' },
  { name: 'Bairagarh', position: { lat: 23.2950, lng: 77.3550 }, kind: 'town' },
  { name: 'Mandideep (industrial belt)', position: { lat: 23.1050, lng: 77.5400 }, kind: 'town' },
];

export const INFRASTRUCTURE_ASSETS: InfrastructureAsset[] = [
  { id: 'INF-001', type: 'school', name: 'Govt. Higher Secondary School, Kolar', position: { lat: 23.185, lng: 77.395 } },
  { id: 'INF-002', type: 'school', name: 'Municipal Primary School, Huzur', position: { lat: 23.198, lng: 77.452 } },
  { id: 'INF-003', type: 'school', name: 'Zilla Parishad School, Bairagarh', position: { lat: 23.288, lng: 77.362 } },
  { id: 'INF-004', type: 'hospital', name: 'District Hospital, Bhopal East', position: { lat: 23.238, lng: 77.445 } },
  { id: 'INF-005', type: 'hospital', name: 'Community Health Centre, Huzur', position: { lat: 23.205, lng: 77.470 } },
  { id: 'INF-006', type: 'highway', name: 'NH-12 Overpass, Bhopal East', position: { lat: 23.31, lng: 77.53 } },
  { id: 'INF-007', type: 'railway', name: 'Bhopal Junction (satellite yard)', position: { lat: 23.267, lng: 77.401 } },
  { id: 'INF-008', type: 'construction', name: 'Metro Corridor Site, Phase II', position: { lat: 23.24, lng: 77.43 } },
  { id: 'INF-009', type: 'construction', name: 'Housing Project, Kolar Road', position: { lat: 23.175, lng: 77.385 } },
  { id: 'INF-010', type: 'village', name: 'Kolar (settlement)', position: { lat: 23.160, lng: 77.370 } },
  { id: 'INF-011', type: 'village', name: 'Huzur (settlement)', position: { lat: 23.185, lng: 77.461 } },
  { id: 'INF-012', type: 'substation', name: '132kV Substation, Bhopal East', position: { lat: 23.225, lng: 77.460 } },
];

export const RADAR_SHADOW_ZONE: LatLng[] = [
  { lat: 23.14, lng: 77.30 },
  { lat: 23.19, lng: 77.28 },
  { lat: 23.20, lng: 77.34 },
  { lat: 23.15, lng: 77.37 },
  { lat: 23.10, lng: 77.34 },
  { lat: 23.14, lng: 77.30 },
];
