import { PageHeading, Panel, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';

const STAGES = ['initiating', 'developing', 'mature', 'decaying'];

export function StormIntelligence() {
  const { state } = useSimulation();
  const storm = state.storm;
  const currentIdx = STAGES.indexOf(storm.stage);

  return (
    <div>
      <PageHeading title="Storm Intelligence" subtitle="Life-cycle stage, trend indicators and terrain influence" actions={<SimulatedTag />} />

      <Panel title="Storm Life-Cycle" className="mb-4">
        <div className="flex items-center">
          {STAGES.map((s, i) => (
            <div key={s} className="flex flex-1 items-center">
              <div className="flex flex-col items-center gap-1">
                <div
                  className="flex h-8 w-8 items-center justify-center rounded-full border-2 text-[11px] font-bold"
                  style={{
                    borderColor: i === currentIdx ? 'var(--gov-blue)' : 'var(--gov-border-strong)',
                    background: i === currentIdx ? 'var(--gov-blue)' : '#fff',
                    color: i === currentIdx ? '#fff' : 'var(--gov-text-faint)',
                  }}
                >
                  {i + 1}
                </div>
                <span
                  className="text-[11px] font-medium capitalize"
                  style={{ color: i === currentIdx ? 'var(--gov-navy)' : 'var(--gov-text-faint)' }}
                >
                  {s}
                </span>
              </div>
              {i < STAGES.length - 1 && <div className="mx-1 h-px flex-1" style={{ background: 'var(--gov-border-strong)' }} />}
            </div>
          ))}
        </div>
        <p className="mt-4 text-[13.5px]" style={{ color: 'var(--gov-text)' }}>
          Current stage: <span className="font-semibold">Developing / Rapidly Intensifying</span>
        </p>
      </Panel>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <TrendCard label="Lightning Trend" value={`${storm.lightningRatePerMin}/min`} trend="up" />
        <TrendCard label="Reflectivity Trend" value={`${storm.reflectivityDbz} dBZ`} trend="up" />
        <TrendCard label="Storm Velocity" value={`${storm.speedKmh} km/h`} trend="flat" />
        <TrendCard label="Intensity Trend" value={storm.intensity} trend="up" />
      </div>

      <Panel title="Terrain Intelligence" className="mt-4">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <MiniStat label="Elevation" value="497 m avg" />
          <MiniStat label="Slope" value="Low–Moderate" />
          <MiniStat label="Terrain Complexity" value="Moderate" />
          <MiniStat label="Terrain Influence" value="Minor uplift enhancement" />
        </div>
        <p className="mt-3 rounded-sm border px-3 py-2 text-[13px]" style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-bg-panel)', color: 'var(--gov-text)' }}>
          Terrain-aware correction applied — elevation and slope data from the regional DEM have been incorporated into the
          convective initiation estimate for the western hill belt of the district.
        </p>
      </Panel>
    </div>
  );
}

function TrendCard({ label, value, trend }: { label: string; value: string; trend: 'up' | 'down' | 'flat' }) {
  const arrow = trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→';
  const color = trend === 'up' ? 'var(--status-warn)' : trend === 'down' ? 'var(--status-safe)' : 'var(--gov-text-muted)';
  return (
    <Panel>
      <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </div>
      <div className="mt-1 flex items-baseline gap-1.5">
        <span className="text-[19px] font-bold font-mono-data capitalize" style={{ color: 'var(--gov-navy)' }}>
          {value}
        </span>
        <span className="text-[16px] font-bold" style={{ color }}>
          {arrow}
        </span>
      </div>
    </Panel>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </div>
      <div className="mt-0.5 text-[13.5px] font-semibold" style={{ color: 'var(--gov-text)' }}>
        {value}
      </div>
    </div>
  );
}
