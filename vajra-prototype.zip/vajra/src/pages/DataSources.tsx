import { PageHeading, Panel, StatusPill, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';
import { formatIst } from '../utils/useClock';
import { LiveMapView } from '../maps/LiveMapView';

const PIPELINE_STEPS = [
  'Radar / Satellite / Lightning / Weather Stations / NWP / Terrain',
  'Data Quality Control',
  'Time Synchronization',
  'Spatial Grid Alignment',
  'Multi-Source Data Fusion',
  'Atmospheric State',
  'Nowcast Model',
];

export function DataSources() {
  const { state, toggleRadarOutage } = useSimulation();

  return (
    <div>
      <PageHeading title="Observation &amp; Data Fusion" subtitle="Multi-source atmospheric observation status and fusion pipeline" actions={<SimulatedTag />} />

      <Panel title="Observation Sources" className="mb-4">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-[13px]">
            <thead>
              <tr className="border-b text-left" style={{ borderColor: 'var(--gov-border)' }}>
                {['Data Source', 'Status', 'Last Update', 'Resolution', 'Coverage', 'Quality', 'Model Weight'].map((h) => (
                  <th key={h} className="px-2 py-2 text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {state.sources.map((s) => (
                <tr key={s.id} className="border-b" style={{ borderColor: 'var(--gov-border)' }}>
                  <td className="px-2 py-2 font-medium" style={{ color: 'var(--gov-text)' }}>
                    {s.name}
                  </td>
                  <td className="px-2 py-2">
                    <StatusPill status={s.status} />
                  </td>
                  <td className="px-2 py-2 font-mono-data" style={{ color: 'var(--gov-text-muted)' }}>
                    {s.status === 'unavailable' ? '—' : formatIst(new Date(s.lastUpdateIso))}
                  </td>
                  <td className="px-2 py-2" style={{ color: 'var(--gov-text-muted)' }}>
                    {s.resolution}
                  </td>
                  <td className="px-2 py-2 font-mono-data">{s.coveragePct}%</td>
                  <td className="px-2 py-2 font-mono-data">{s.qualityPct}%</td>
                  <td className="px-2 py-2 font-mono-data">{s.modelWeightPct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-[11px]" style={{ color: 'var(--gov-text-faint)' }}>
            Values shown are prototype simulated data for demonstration purposes.
          </p>
          <button
            onClick={toggleRadarOutage}
            className="rounded-sm border px-3 py-1.5 text-[12px] font-semibold"
            style={{ borderColor: 'var(--gov-border-strong)', color: 'var(--gov-navy)' }}
          >
            {state.radarOutage ? 'Restore Radar (simulate)' : 'Simulate Radar Outage'}
          </button>
        </div>

        {state.radarOutage && (
          <div className="mt-3 rounded-sm border px-3 py-2 text-[13px]" style={{ borderColor: 'var(--status-warn)', background: 'var(--status-warn-bg)', color: 'var(--status-warn)' }}>
            <strong>Radar data unavailable.</strong> Dynamic source weighting activated — model weight has shifted toward satellite,
            lightning and weather-station observations for this region.
          </div>
        )}
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Spatio-Temporal Data Fusion">
          <div className="flex flex-col items-stretch gap-1.5">
            {PIPELINE_STEPS.map((step, i) => (
              <div key={step}>
                <div
                  className="rounded-sm border px-3 py-2 text-center text-[12.5px] font-medium"
                  style={{ borderColor: 'var(--gov-border-strong)', background: i === PIPELINE_STEPS.length - 1 ? 'var(--gov-bg-panel)' : '#fff', color: 'var(--gov-text)' }}
                >
                  {step}
                </div>
                {i < PIPELINE_STEPS.length - 1 && (
                  <div className="flex justify-center py-0.5 text-[13px]" style={{ color: 'var(--gov-text-faint)' }}>
                    ↓
                  </div>
                )}
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Coverage Gap Intelligence">
          <p className="mb-2 text-[13px]" style={{ color: 'var(--gov-text-muted)' }}>
            Limited direct radar observation is available for the highlighted sector southwest of Bhopal.
          </p>
          <LiveMapView showInfrastructure={false} showRadarShadow height="260px" />
          <div className="mt-3 rounded-sm border px-3 py-2 text-[13px]" style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-bg-panel)' }}>
            <p style={{ color: 'var(--gov-text)' }}>
              Satellite + Lightning + Nearby Radar + Weather Stations + NWP + Terrain →{' '}
              <span className="font-semibold">Virtual Radar Estimate</span>
            </p>
            <p className="mt-1 text-[12px]" style={{ color: 'var(--gov-text-muted)' }}>
              Estimated atmospheric field generated from available observations. Confidence: 78%. This does not replace direct
              radar observation.
            </p>
          </div>
        </Panel>
      </div>
    </div>
  );
}
