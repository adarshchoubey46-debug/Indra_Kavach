import { PageHeading, Panel, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';
import { formatIst } from '../utils/useClock';
import { Link } from 'react-router-dom';

const SEVERITY_LABEL: Record<string, { label: string; bg: string; fg: string }> = {
  low: { label: 'GREEN ALERT', bg: 'var(--status-safe-bg)', fg: 'var(--status-safe)' },
  moderate: { label: 'YELLOW ALERT', bg: 'var(--status-watch-bg)', fg: 'var(--status-watch)' },
  high: { label: 'ORANGE ALERT', bg: 'var(--status-warn-bg)', fg: 'var(--status-warn)' },
  severe: { label: 'RED ALERT', bg: 'var(--status-severe-bg)', fg: 'var(--status-severe)' },
};

export function Alerts() {
  const { state, acknowledgeAlert } = useSimulation();

  return (
    <div>
      <PageHeading title="Warning &amp; Alert Centre" subtitle="Impact-based warnings issued for Bhopal district" actions={<SimulatedTag />} />

      <div className="space-y-3">
        {state.alerts.map((alert) => {
          const s = SEVERITY_LABEL[alert.severity];
          return (
            <Panel key={alert.id} className="!p-0">
              <div className="flex items-center justify-between border-b px-4 py-2" style={{ borderColor: 'var(--gov-border)', background: s.bg }}>
                <span className="text-[13px] font-bold tracking-wide" style={{ color: s.fg }}>
                  {s.label}
                </span>
                <span className="text-[11.5px] font-mono-data" style={{ color: s.fg }}>
                  {alert.id}
                </span>
              </div>
              <div className="p-4">
                <p className="text-[15px] font-semibold" style={{ color: 'var(--gov-navy)' }}>
                  {alert.hazard} expected — {alert.area}
                </p>
                <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Field label="Issued" value={formatIst(new Date(alert.issuedIso))} />
                  <Field label="Valid Until" value={formatIst(new Date(alert.validUntilIso))} />
                  <Field label="Confidence" value={`${alert.confidencePct}%`} />
                  <Field label="Area" value={alert.area} />
                </div>
                <div className="mt-3 border-t pt-3 text-[13.5px]" style={{ borderColor: 'var(--gov-border)' }}>
                  <span className="font-semibold" style={{ color: 'var(--gov-navy)' }}>
                    Recommended Action:{' '}
                  </span>
                  <span style={{ color: 'var(--gov-text)' }}>{alert.action}</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Link
                    to="/live-map"
                    className="rounded-sm border px-3 py-1.5 text-[12.5px] font-semibold"
                    style={{ borderColor: 'var(--gov-border-strong)', color: 'var(--gov-navy)' }}
                  >
                    View on Map
                  </Link>
                  <button
                    onClick={() => acknowledgeAlert(alert.id)}
                    disabled={alert.acknowledged}
                    className="rounded-sm px-3 py-1.5 text-[12.5px] font-semibold text-white disabled:opacity-50"
                    style={{ background: 'var(--gov-blue)' }}
                  >
                    {alert.acknowledged ? 'Acknowledged' : 'Acknowledge'}
                  </button>
                  <button
                    className="rounded-sm border px-3 py-1.5 text-[12.5px] font-semibold"
                    style={{ borderColor: 'var(--status-severe)', color: 'var(--status-severe)' }}
                  >
                    Escalate
                  </button>
                </div>
              </div>
            </Panel>
          );
        })}

        {state.alerts.length === 0 && (
          <Panel>
            <p className="text-[13.5px]" style={{ color: 'var(--gov-text-muted)' }}>
              No active alerts for the selected region.
            </p>
          </Panel>
        )}
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10.5px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </div>
      <div className="text-[13px] font-semibold" style={{ color: 'var(--gov-text)' }}>
        {value}
      </div>
    </div>
  );
}
