import { useState } from 'react';
import { PageHeading, Panel, SimulatedTag } from '../components/Primitives';

const TIMELINE = ['T-60', 'T-45', 'T-30', 'T-15', 'T0', 'T+15', 'T+30'];

const NARRATIVE: Record<string, string> = {
  'T-60': 'Early convective indicators detected over southwestern sector; no organized cell yet.',
  'T-45': 'Cell initiation confirmed via satellite; lightning activity begins.',
  'T-30': 'Cell organizing; reflectivity increasing, nowcast model issues first trajectory.',
  'T-15': 'Rapid intensification; lightning rate crosses warning threshold.',
  T0: 'Cell reaches mature stage over Bhopal East; impact-based warning issued.',
  'T+15': 'Cell begins decaying; lightning rate declining.',
  'T+30': 'Event concluded; forecast verification run against observed track.',
};

export function HistoricalEvents() {
  const [idx, setIdx] = useState(4);

  return (
    <div>
      <PageHeading title="Historical Event Replay" subtitle="MP-TH-042 — Bhopal district, illustrative past event" actions={<SimulatedTag />} />

      <Panel title="Event Timeline">
        <div className="mb-4 flex items-center justify-between">
          {TIMELINE.map((t, i) => (
            <button
              key={t}
              onClick={() => setIdx(i)}
              className="flex flex-col items-center gap-1"
            >
              <span
                className="flex h-7 w-7 items-center justify-center rounded-full border-2 text-[10px] font-bold"
                style={{
                  borderColor: i === idx ? 'var(--gov-blue)' : 'var(--gov-border-strong)',
                  background: i === idx ? 'var(--gov-blue)' : '#fff',
                  color: i === idx ? '#fff' : 'var(--gov-text-faint)',
                }}
              >
                {i + 1}
              </span>
              <span className="text-[10.5px] font-mono-data" style={{ color: i === idx ? 'var(--gov-navy)' : 'var(--gov-text-faint)' }}>
                {t}
              </span>
            </button>
          ))}
        </div>
        <input
          type="range"
          min={0}
          max={TIMELINE.length - 1}
          value={idx}
          onChange={(e) => setIdx(Number(e.target.value))}
          className="w-full"
        />
        <p className="mt-4 text-[14px]" style={{ color: 'var(--gov-text)' }}>
          {NARRATIVE[TIMELINE[idx]]}
        </p>
      </Panel>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Panel title="Predicted Trajectory">
          <p className="text-[13px]" style={{ color: 'var(--gov-text-muted)' }}>
            Model-predicted storm centre track, generated at T-30.
          </p>
        </Panel>
        <Panel title="Actual Trajectory">
          <p className="text-[13px]" style={{ color: 'var(--gov-text-muted)' }}>
            Observed storm centre track, reconstructed from radar and lightning data post-event.
          </p>
        </Panel>
        <Panel title="Forecast Error">
          <div className="space-y-1 text-[13px]">
            <div className="flex justify-between">
              <span style={{ color: 'var(--gov-text-muted)' }}>Location error</span>
              <span className="font-mono-data font-semibold">7.2 km</span>
            </div>
            <div className="flex justify-between">
              <span style={{ color: 'var(--gov-text-muted)' }}>Arrival-time error</span>
              <span className="font-mono-data font-semibold">6 min</span>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}
