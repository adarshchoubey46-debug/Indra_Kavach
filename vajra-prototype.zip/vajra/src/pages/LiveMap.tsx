import { useState } from 'react';
import { LiveMapView } from '../maps/LiveMapView';
import { PageHeading, Panel, DataRow, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';
import { headingToCompass, arrivalWindowLabel } from '../simulation/engine';
import { formatIst } from '../utils/useClock';

const LAYER_TOGGLES = [
  'Base Map',
  'Satellite',
  'Radar',
  'Lightning',
  'Thunderstorm Probability',
  'Storm Track',
  'Risk Zones',
  'Terrain',
  'Critical Infrastructure',
  'Population Exposure',
];

export function LiveMap() {
  const { state } = useSimulation();
  const storm = state.storm;
  const [active, setActive] = useState<string[]>(['Base Map', 'Storm Track', 'Critical Infrastructure']);

  function toggle(name: string) {
    setActive((prev) => (prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]));
  }

  return (
    <div>
      <PageHeading title="Live Map" subtitle="Operational geospatial view — Bhopal district, Madhya Pradesh" actions={<SimulatedTag />} />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[220px_1fr_300px]">
        {/* Map controls */}
        <Panel title="Map Layers">
          <div className="flex flex-col gap-1.5">
            {LAYER_TOGGLES.map((name) => (
              <button
                key={name}
                onClick={() => toggle(name)}
                className="flex items-center gap-2 rounded-sm px-2 py-1.5 text-left text-[12.5px]"
                style={{
                  background: active.includes(name) ? 'var(--gov-bg-panel)' : 'transparent',
                  color: active.includes(name) ? 'var(--gov-navy)' : 'var(--gov-text-muted)',
                  fontWeight: active.includes(name) ? 600 : 400,
                }}
              >
                <span
                  className="inline-block h-3 w-3 flex-shrink-0 border"
                  style={{
                    borderColor: 'var(--gov-border-strong)',
                    background: active.includes(name) ? 'var(--gov-blue)' : 'transparent',
                  }}
                />
                {name}
              </button>
            ))}
          </div>
          <p className="mt-3 text-[11px]" style={{ color: 'var(--gov-text-faint)' }}>
            Radar and Lightning layers are represented via storm track and intensity data in this prototype; live tile feeds are not connected.
          </p>
        </Panel>

        {/* Map */}
        <div>
          <LiveMapView height="620px" />
        </div>

        {/* Nowcast panel */}
        <Panel title="Current Nowcast">
          <DataRow label="Selected Region" value="Bhopal District" mono={false} />
          <DataRow label="Thunderstorm Probability" value={`${storm.thunderstormProbabilityPct}%`} />
          <DataRow label="Lightning Probability" value={`${storm.lightningProbabilityPct}%`} />
          <DataRow label="Current Intensity" value={storm.intensity} mono={false} />
          <DataRow label="Storm Direction" value={headingToCompass(storm.headingDeg)} />
          <DataRow label="Storm Speed" value={`${storm.speedKmh} km/h`} />
          <DataRow label="Expected Arrival" value={arrivalWindowLabel(storm)} />
          <DataRow label="Prediction Confidence" value={`${storm.predictionConfidencePct}%`} />
          <DataRow label="Last Updated" value={formatIst(new Date(state.nowIso))} />

          <div className="mt-3 border-t pt-3" style={{ borderColor: 'var(--gov-border)' }}>
            <h4 className="mb-1.5 text-[12px] font-semibold" style={{ color: 'var(--gov-navy)' }}>
              Arrival Confidence by Horizon
            </h4>
            <div className="space-y-1">
              {storm.track.slice(1).map((p) => (
                <div key={p.tMinutes} className="flex items-center gap-2">
                  <span className="w-14 text-[11px] font-mono-data" style={{ color: 'var(--gov-text-muted)' }}>
                    +{p.tMinutes} min
                  </span>
                  <div className="h-2 flex-1 overflow-hidden rounded-sm" style={{ background: 'var(--gov-bg-alt)' }}>
                    <div
                      className="h-full"
                      style={{
                        width: `${p.confidencePct}%`,
                        background: p.confidencePct > 80 ? 'var(--status-safe)' : p.confidencePct > 65 ? 'var(--status-watch)' : 'var(--status-warn)',
                      }}
                    />
                  </div>
                  <span className="w-9 text-right text-[11px] font-mono-data" style={{ color: 'var(--gov-text)' }}>
                    {p.confidencePct}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}
