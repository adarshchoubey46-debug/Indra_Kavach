import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSimulation } from '../services/SimulationContext';
import { Panel, DataRow, RiskBadge, SimulatedTag } from '../components/Primitives';
import { formatIst } from '../utils/useClock';
import { headingToCompass, arrivalWindowLabel } from '../simulation/engine';

export function Home() {
  const { state } = useSimulation();
  const [stateVal, setStateVal] = useState('Madhya Pradesh');
  const [district, setDistrict] = useState('Bhopal');
  const [horizon, setHorizon] = useState('60');

  const storm = state.storm;

  return (
    <div className="space-y-4">
      <Panel>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-[22px] font-bold" style={{ color: 'var(--gov-navy)' }}>
              Thunderstorm &amp; Lightning Nowcast
            </h1>
            <p className="mt-1 max-w-2xl text-[13.5px]" style={{ color: 'var(--gov-text-muted)' }}>
              Short-term atmospheric intelligence for early action and disaster preparedness.
            </p>
          </div>
          <SimulatedTag />
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 border-t pt-4 sm:grid-cols-3" style={{ borderColor: 'var(--gov-border)' }}>
          <label className="block">
            <span className="mb-1 block text-[11.5px] font-medium" style={{ color: 'var(--gov-text-muted)' }}>
              State
            </span>
            <select
              value={stateVal}
              onChange={(e) => setStateVal(e.target.value)}
              className="w-full rounded-sm border px-2.5 py-1.5 text-[13.5px]"
              style={{ borderColor: 'var(--gov-border-strong)' }}
            >
              <option>Madhya Pradesh</option>
              <option>Kerala</option>
              <option>Odisha</option>
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-[11.5px] font-medium" style={{ color: 'var(--gov-text-muted)' }}>
              District
            </span>
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="w-full rounded-sm border px-2.5 py-1.5 text-[13.5px]"
              style={{ borderColor: 'var(--gov-border-strong)' }}
            >
              <option>Bhopal</option>
              <option>Indore</option>
              <option>Jabalpur</option>
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-[11.5px] font-medium" style={{ color: 'var(--gov-text-muted)' }}>
              Forecast Horizon
            </span>
            <select
              value={horizon}
              onChange={(e) => setHorizon(e.target.value)}
              className="w-full rounded-sm border px-2.5 py-1.5 text-[13.5px]"
              style={{ borderColor: 'var(--gov-border-strong)' }}
            >
              <option value="30">30 minutes</option>
              <option value="60">60 minutes</option>
              <option value="120">120 minutes</option>
            </select>
          </label>
        </div>
      </Panel>

      {/* Live status strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Panel>
          <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
            System Status
          </div>
          <div className="mt-1 text-[19px] font-bold" style={{ color: 'var(--status-safe)' }}>
            Operational
          </div>
        </Panel>
        <Panel>
          <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
            Data Updated
          </div>
          <div className="mt-1 text-[19px] font-bold font-mono-data" style={{ color: 'var(--gov-text)' }}>
            {formatIst(new Date(state.nowIso))}
          </div>
        </Panel>
        <Panel>
          <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
            Active Storm Cells
          </div>
          <div className="mt-1 text-[19px] font-bold font-mono-data" style={{ color: 'var(--gov-navy)' }}>
            {String(state.activeCells).padStart(2, '0')}
          </div>
        </Panel>
        <Panel>
          <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
            High-Risk Zones
          </div>
          <div className="mt-1 text-[19px] font-bold font-mono-data" style={{ color: 'var(--status-warn)' }}>
            {String(state.highRiskZones).padStart(2, '0')}
          </div>
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Current Situation" className="lg:col-span-2">
          <p className="text-[14px] leading-relaxed" style={{ color: 'var(--gov-text)' }}>
            Convective activity is intensifying over central Madhya Pradesh. Storm cell{' '}
            <span className="font-mono-data font-semibold">{storm.id}</span> is in the{' '}
            <span className="font-semibold">{storm.stage}</span> stage, moving {headingToCompass(storm.headingDeg)} at{' '}
            {storm.speedKmh} km/h with increasing lightning activity. Expected arrival over Bhopal district in{' '}
            {arrivalWindowLabel(storm)}.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <RiskBadge level={state.impact.riskLevel} />
            <Link
              to="/live-map"
              className="rounded-sm px-3 py-1.5 text-[13px] font-semibold text-white"
              style={{ background: 'var(--gov-blue)' }}
            >
              View on Live Map
            </Link>
            <Link
              to="/impact-assessment"
              className="rounded-sm border px-3 py-1.5 text-[13px] font-semibold"
              style={{ borderColor: 'var(--gov-border-strong)', color: 'var(--gov-navy)' }}
            >
              View Impact Assessment
            </Link>
          </div>
        </Panel>

        <Panel title="Nowcast Summary">
          <DataRow label="Thunderstorm Probability" value={`${storm.thunderstormProbabilityPct}%`} />
          <DataRow label="Lightning Probability" value={`${storm.lightningProbabilityPct}%`} />
          <DataRow label="Intensity" value={storm.intensity} mono={false} />
          <DataRow label="Direction" value={headingToCompass(storm.headingDeg)} />
          <DataRow label="Speed" value={`${storm.speedKmh} km/h`} />
          <DataRow label="Confidence" value={`${storm.predictionConfidencePct}%`} />
        </Panel>
      </div>
    </div>
  );
}
