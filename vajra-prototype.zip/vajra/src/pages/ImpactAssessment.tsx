import { PageHeading, Panel, RiskBadge, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';
import { LiveMapView } from '../maps/LiveMapView';
import { ROLE_LABELS, recommendedAction } from '../data/roleActions';
import type { Role, InfrastructureAsset } from '../types';
import { arrivalWindowLabel } from '../simulation/engine';

const ASSET_LABEL: Record<InfrastructureAsset['type'], string> = {
  school: 'Schools',
  hospital: 'Hospitals',
  highway: 'Highway segments',
  railway: 'Railway assets',
  construction: 'Construction sites',
  village: 'Villages',
  substation: 'Power substations',
  city: 'Cities',
};

function groupAssets(assets: InfrastructureAsset[]) {
  const counts: Partial<Record<InfrastructureAsset['type'], number>> = {};
  for (const a of assets) counts[a.type] = (counts[a.type] ?? 0) + 1;
  return counts;
}

export function ImpactAssessment() {
  const { state, role, setRole } = useSimulation();
  const impact = state.impact;
  const storm = state.storm;
  const counts = groupAssets(impact.assetsInZone);

  return (
    <div>
      <PageHeading title="Impact Assessment" subtitle="Hazard, exposure and vulnerability combined into projected impact" actions={<SimulatedTag />} />

      {/* Formula strip */}
      <Panel className="mb-4">
        <div className="flex flex-wrap items-center justify-center gap-3 py-1 text-center">
          <FormulaBlock label="Weather Hazard" value={`${storm.thunderstormProbabilityPct}% probability`} />
          <Plus />
          <FormulaBlock label="Exposure" value={`${impact.assetsInZone.length} assets in zone`} />
          <Plus />
          <FormulaBlock label="Vulnerability" value={`${impact.outdoorExposure} outdoor exposure`} />
          <span className="text-[18px] font-bold" style={{ color: 'var(--gov-text-faint)' }}>
            =
          </span>
          <FormulaBlock label="Impact Risk" value={<RiskBadge level={impact.riskLevel} />} highlight />
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1.3fr_1fr]">
        <div>
          <LiveMapView showInfrastructure height="480px" />
        </div>

        <div className="space-y-4">
          <Panel title="Projected High-Risk Area">
            <p className="mb-2 text-[13px]" style={{ color: 'var(--gov-text-muted)' }}>
              Projected zone (+15 min position, Bhopal East) contains:
            </p>
            <ul className="space-y-1 text-[13.5px]">
              {Object.entries(counts).map(([type, count]) => (
                <li key={type} className="flex justify-between border-b py-1" style={{ borderColor: 'var(--gov-border)' }}>
                  <span>{ASSET_LABEL[type as InfrastructureAsset['type']]}</span>
                  <span className="font-mono-data font-semibold">{count}</span>
                </li>
              ))}
              {impact.assetsInZone.length === 0 && (
                <li className="text-[13px]" style={{ color: 'var(--gov-text-faint)' }}>
                  No mapped critical assets currently within projected zone.
                </li>
              )}
            </ul>
          </Panel>

          <div className="grid grid-cols-2 gap-3">
            <Panel>
              <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
                Estimated Exposed Population
              </div>
              <div className="mt-1 text-[20px] font-bold font-mono-data" style={{ color: 'var(--gov-navy)' }}>
                {impact.exposedPopulation.toLocaleString('en-IN')}
              </div>
            </Panel>
            <Panel>
              <div className="text-[11px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
                Critical Facilities
              </div>
              <div className="mt-1 text-[20px] font-bold font-mono-data" style={{ color: 'var(--gov-navy)' }}>
                {impact.criticalFacilities}
              </div>
            </Panel>
          </div>
        </div>
      </div>

      {/* Impact-based warning bulletin */}
      <Panel title="Impact-Based Warning" className="mt-4">
        <div className="grid grid-cols-1 gap-x-8 gap-y-2 sm:grid-cols-2">
          <BulletinRow label="Hazard" value="Severe thunderstorm with lightning" />
          <BulletinRow label="Location" value="Bhopal East" />
          <BulletinRow label="Expected Impact" value={arrivalWindowLabel(storm)} />
          <BulletinRow label="Exposed Assets" value="School / Highway / Construction Zone" />
          <BulletinRow label="Risk" value={<RiskBadge level={impact.riskLevel} small />} />
          <BulletinRow label="Recommended Action" value="Restrict outdoor activity and issue local warning." />
        </div>
      </Panel>

      {/* Role-based decision support */}
      <Panel title="Role-Based Decision Support" className="mt-4">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {(Object.keys(ROLE_LABELS) as Role[]).map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className="rounded-sm border px-2.5 py-1 text-[12px] font-medium"
              style={{
                borderColor: role === r ? 'var(--gov-blue)' : 'var(--gov-border-strong)',
                background: role === r ? 'var(--gov-blue)' : 'transparent',
                color: role === r ? '#fff' : 'var(--gov-text)',
              }}
            >
              {ROLE_LABELS[r]}
            </button>
          ))}
        </div>
        <div className="border-l-4 pl-3" style={{ borderColor: 'var(--gov-blue)' }}>
          <div className="text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
            {ROLE_LABELS[role]}
          </div>
          <p className="mt-0.5 text-[14px]" style={{ color: 'var(--gov-text)' }}>
            {recommendedAction(role)}
          </p>
        </div>
      </Panel>
    </div>
  );
}

function FormulaBlock({ label, value, highlight }: { label: string; value: React.ReactNode; highlight?: boolean }) {
  return (
    <div
      className="min-w-[140px] rounded-sm border px-3 py-2 text-center"
      style={{
        borderColor: highlight ? 'var(--gov-blue)' : 'var(--gov-border)',
        background: highlight ? 'var(--gov-bg-panel)' : '#fff',
      }}
    >
      <div className="text-[10.5px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </div>
      <div className="mt-0.5 text-[13.5px] font-semibold" style={{ color: 'var(--gov-navy)' }}>
        {value}
      </div>
    </div>
  );
}

function Plus() {
  return (
    <span className="text-[18px] font-bold" style={{ color: 'var(--gov-text-faint)' }}>
      +
    </span>
  );
}

function BulletinRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between border-b py-1.5" style={{ borderColor: 'var(--gov-border)' }}>
      <span className="text-[12px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </span>
      <span className="text-[13.5px] font-semibold" style={{ color: 'var(--gov-text)' }}>
        {value}
      </span>
    </div>
  );
}
