import { PageHeading, Panel } from '../components/Primitives';

export function About() {
  return (
    <div>
      <PageHeading title="About VAJRA" subtitle="Thunderstorm & Lightning Nowcasting System" />
      <Panel>
        <p className="text-[14px] leading-relaxed" style={{ color: 'var(--gov-text)' }}>
          VAJRA is a prototype decision-support system for short-term (0–60 minute) nowcasting of thunderstorms and
          lightning, developed for Smart India Hackathon 2026, Problem Statement 72 — "AI/ML based Nowcasting of
          Thunderstorm and Lightning using atmospheric observations including multiple radars, satellite, lightning and
          model data."
        </p>
        <p className="mt-3 text-[14px] leading-relaxed" style={{ color: 'var(--gov-text)' }}>
          The system combines radar, satellite, lightning-network, automatic weather station, numerical weather prediction
          and terrain data into a fused atmospheric state, from which convective cell trajectories, arrival windows and
          impact-based warnings are generated. Impact assessment layers hazard probability with exposure and
          vulnerability data to translate probability into actionable guidance for meteorological officers, district
          administrations, disaster management authorities, schools, utility operators and the public.
        </p>
        <p className="mt-3 rounded-sm border px-3 py-2 text-[13px]" style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-bg-panel)', color: 'var(--gov-text-muted)' }}>
          This is a hackathon prototype. All observation values, storm positions, exposure figures and verification
          metrics displayed are simulated for demonstration and are not live government data. The interface follows
          general conventions of Government of India digital service portals but does not reproduce any official
          department's exact branding, logo or layout.
        </p>
      </Panel>
    </div>
  );
}
