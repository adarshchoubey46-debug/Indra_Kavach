import { PageHeading, Panel, DataRow, SimulatedTag } from '../components/Primitives';
import { useSimulation } from '../services/SimulationContext';
import { headingToCompass, arrivalWindowLabel } from '../simulation/engine';
import { formatIst } from '../utils/useClock';

export function Nowcast() {
  const { state } = useSimulation();
  const storm = state.storm;

  return (
    <div>
      <PageHeading title="Nowcast" subtitle="0–60 minute thunderstorm and lightning nowcast for Bhopal district" actions={<SimulatedTag />} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Storm Cell Summary">
          <DataRow label="Cell ID" value={storm.id} />
          <DataRow label="Stage" value={storm.stage} mono={false} />
          <DataRow label="Thunderstorm Probability" value={`${storm.thunderstormProbabilityPct}%`} />
          <DataRow label="Lightning Probability" value={`${storm.lightningProbabilityPct}%`} />
          <DataRow label="Lightning Rate" value={`${storm.lightningRatePerMin} strikes/min`} />
          <DataRow label="Reflectivity" value={`${storm.reflectivityDbz} dBZ`} />
          <DataRow label="Direction" value={headingToCompass(storm.headingDeg)} />
          <DataRow label="Speed" value={`${storm.speedKmh} km/h`} />
          <DataRow label="Expected Arrival" value={arrivalWindowLabel(storm)} />
          <DataRow label="Last Updated" value={formatIst(new Date(state.nowIso))} />
        </Panel>

        <Panel title="Forecast Confidence by Horizon">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b text-left" style={{ borderColor: 'var(--gov-border)' }}>
                <th className="py-1.5 text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>Horizon</th>
                <th className="py-1.5 text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>Position (lat, lng)</th>
                <th className="py-1.5 text-right text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>Confidence</th>
              </tr>
            </thead>
            <tbody>
              {storm.track.map((p) => (
                <tr key={p.tMinutes} className="border-b" style={{ borderColor: 'var(--gov-border)' }}>
                  <td className="py-1.5 font-medium">{p.tMinutes === 0 ? 'Current' : `+${p.tMinutes} min`}</td>
                  <td className="py-1.5 font-mono-data" style={{ color: 'var(--gov-text-muted)' }}>
                    {p.lat.toFixed(3)}, {p.lng.toFixed(3)}
                  </td>
                  <td className="py-1.5 text-right font-mono-data font-semibold">{p.confidencePct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-3 text-[12px]" style={{ color: 'var(--gov-text-muted)' }}>
            Prediction confidence decreases with forecast horizon, reflecting increasing atmospheric uncertainty. The
            uncertainty cone on the Live Map widens accordingly.
          </p>
        </Panel>
      </div>
    </div>
  );
}
