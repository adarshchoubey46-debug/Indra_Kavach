import { PageHeading, Panel, SimulatedTag } from '../components/Primitives';

export function Analytics() {
  return (
    <div>
      <PageHeading title="Analytics" subtitle="Forecast reliability and verification against simulated event data" actions={<SimulatedTag />} />

      <Panel title="Forecast Reliability" className="mb-4">
        <p className="mb-3 text-[11.5px]" style={{ color: 'var(--gov-text-faint)' }}>
          Prototype validation metrics using simulated event data — not actual IMD performance figures.
        </p>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          <Metric label="Probability of Detection" value="0.86" />
          <Metric label="False Alarm Ratio" value="0.14" />
          <Metric label="Critical Success Index" value="0.75" />
          <Metric label="Mean Location Error" value="7.2 km" />
          <Metric label="Mean Arrival-Time Error" value="6 min" />
          <Metric label="Average Lead Time" value="24 min" />
        </div>
      </Panel>

      <Panel title="Forecast Verification &amp; Learning">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1 text-[13px]">
            <div className="flex justify-between border-b py-1" style={{ borderColor: 'var(--gov-border)' }}>
              <span style={{ color: 'var(--gov-text-muted)' }}>Predicted storm centre</span>
              <span className="font-mono-data font-semibold">23.301°N, 77.462°E</span>
            </div>
            <div className="flex justify-between border-b py-1" style={{ borderColor: 'var(--gov-border)' }}>
              <span style={{ color: 'var(--gov-text-muted)' }}>Observed storm centre</span>
              <span className="font-mono-data font-semibold">23.286°N, 77.441°E</span>
            </div>
            <div className="flex justify-between border-b py-1" style={{ borderColor: 'var(--gov-border)' }}>
              <span style={{ color: 'var(--gov-text-muted)' }}>Predicted arrival</span>
              <span className="font-mono-data font-semibold">14:58 IST</span>
            </div>
            <div className="flex justify-between py-1">
              <span style={{ color: 'var(--gov-text-muted)' }}>Observed arrival</span>
              <span className="font-mono-data font-semibold">15:04 IST</span>
            </div>
          </div>
          <div className="flex flex-col justify-center gap-1.5 rounded-sm border px-3 py-3 text-center text-[12.5px]" style={{ borderColor: 'var(--gov-border)', background: 'var(--gov-bg-panel)' }}>
            <span>Forecast Error (7.2 km / 6 min)</span>
            <span style={{ color: 'var(--gov-text-faint)' }}>↓</span>
            <span>Regional Bias Detection</span>
            <span style={{ color: 'var(--gov-text-faint)' }}>↓</span>
            <span>Correction Applied</span>
            <span style={{ color: 'var(--gov-text-faint)' }}>↓</span>
            <span className="font-semibold" style={{ color: 'var(--gov-navy)' }}>
              Next Forecast (bias-adjusted)
            </span>
          </div>
        </div>
        <p className="mt-3 text-[12px]" style={{ color: 'var(--gov-text-muted)' }}>
          This verification loop informs regional bias correction for subsequent nowcasts. It does not represent an
          autonomous production deployment; corrections are reviewed by duty meteorological staff.
        </p>
      </Panel>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10.5px] font-medium uppercase tracking-wide" style={{ color: 'var(--gov-text-faint)' }}>
        {label}
      </div>
      <div className="mt-0.5 text-[17px] font-bold font-mono-data" style={{ color: 'var(--gov-navy)' }}>
        {value}
      </div>
    </div>
  );
}
